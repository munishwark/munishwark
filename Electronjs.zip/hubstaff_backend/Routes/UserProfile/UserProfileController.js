/*jshint esversion: 6 */

import 'babel-polyfill';
import crypto from 'crypto';
import Grid from 'gridfs-stream';
import mongoose from 'mongoose';
import multer from 'multer';
import GridFsStorage from 'multer-gridfs-storage';
import path from 'path';
import db from '../../db';
var fs = require('fs');
var bodyParser = require('body-parser');
var express = require('express');
var router = express.Router();
const Profile = require('./Userprofile');
// var Employee = require('../employees/Employee');

/** Connecting DataBase For gridfs-stream **/
/** STARTs **/
const connection = db.connection;
// Init gfs
let gfs;
connection.once('open', () => {
    // console.log('MongoDB database connection established successfully!');
    // Init stream
    gfs = Grid(connection.db, mongoose.mongo);
    gfs.collection('uploads');
});
/** ENDs **/

router.use(bodyParser.urlencoded({
    extended: true
}));

// Create storage engine
const storage = new GridFsStorage({
    url: 'mongodb://localhost:27017/issues',
    file: (req, file) => {
        return new Promise((resolve, reject) => {
            crypto.randomBytes(16, (err, buf) => {
                if (err) {
                    return reject(err);
                }
                const filename = buf.toString('hex') + path.extname(file.originalname);
                const fileInfo = {
                    filename: filename,
                    bucketName: 'uploads'
                };
                resolve(fileInfo);
            });
        });
    }
});
const upload = multer({
    storage
});

// @route GET /
// @desc Loads form
router.get('/', (req, res) => {
    gfs.files.find().toArray((err, files) => {
        // Check if files
        if (!files || files.length === 0) {
            res.render('index', {
                files: false
            });
        } else {
            files.map(file => {
                if (
                    file.contentType === 'image/jpeg' ||
                    file.contentType === 'image/png'
                ) {
                    file.isImage = true;
                } else {
                    file.isImage = false;
                }
            });
            res.json({
                files: files
            });
        }
    });
});

// @route POST /upload
// @desc  Uploads file to DB
router.post('/upload/:employeeID', upload.single('file'), async (req, res, next) => {
    try {
        // Get the userId
        const employeeID = req.params;

        // 1. Find the Employee
        const empData = await Employee.findById(employeeID);

        // 2. Add image source to founded employee's image data
        empData.img.data = req.file.filename;
        empData.img.contentType = req.file.contentType
        await empData.save();

        let profile_schema_data = {
            employee: empData,
            file_data: req.file
        }

        // 3. Create a Profile
        const newProfile = new Profile(profile_schema_data);
        const profile = await newProfile.save();

        res.status(201).json({
            profile,
            // file: req.file,
            // empData,
            "status": true
        });
    } catch (err) {
        next(err);
    }

});

// @route GET /files
// @desc  Display all files in JSON
router.get('/files', (req, res) => {

    gfs.files.find().toArray((err, files) => {
        console.log(files, '---->>>111');

        // Check if files
        if (!files || files.length === 0) {
            return res.status(404).json({
                err: 'No files exist'
            });
        }

        // Files exist
        return res.json(files);
    });
});

// @route GET /files/:filename
// @desc  Display single file object
router.get('/files/:filename', (req, res) => {
    gfs.files.findOne({
        filename: req.params.filename
    }, (err, file) => {
        // Check if file
        if (!file || file.length === 0) {
            return res.status(404).json({
                err: 'No file exists'
            });
        }
        // File exists
        return res.json(file);
    });
});

// @route GET /image/:filename
// @desc Display Image
router.get('/image/:filename', (req, res) => {
    gfs.files.findOne({
        filename: req.params.filename
    }, (err, file) => {
        // Check if file
        if (!file || file.length === 0) {
            return res.status(404).json({
                err: 'No file exists'
            });
        }

        // Check if image
        if (file.contentType === 'image/jpeg' || file.contentType === 'image/png') {
            // Read output to browser
            const readstream = gfs.createReadStream(file.filename);
            readstream.pipe(res);
            // res.status(404).send(readstream);
        } else {
            res.status(404).json({
                err: 'Not an image'
            });
        }
    });
});

// @route DELETE /files/:id
// @desc  Delete file
router.delete('/files/:id', (req, res) => {
    gfs.remove({
        _id: req.params.id,
        root: 'uploads'
    }, (err, gridStore) => {
        if (err) {
            return res.status(404).json({
                err: err
            });
        }

        res.redirect('/');
    });
});

module.exports = router;