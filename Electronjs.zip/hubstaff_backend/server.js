/*jshint esversion: 6 */
import 'babel-polyfill';
import bodyParser from 'body-parser';
import cors from 'cors';
import express from 'express';
import methodOverride from 'method-override';
import autoIncrement from 'mongoose-auto-increment';
import mongoConnection from './db';
// import EmployeeRole from './Routes/models/employeeRole';
// import Technology from './Routes/models/technology';


const app = express();
const router = express.Router();
global.__root = __dirname + '/';

process.on('uncaughtException', function (err) {
    console.log(err);
});
/** Middlewares **/
app.use(cors());
app.use(bodyParser.json());
app.use(methodOverride('_method'));

/** Connecting DataBase For gridfs-stream **/
/** STARTs **/
const connection = mongoConnection.connection;
autoIncrement.initialize(connection);
connection.once('open', () => {
    console.log('MongoDB database connection established successfully!');
});
/** ENDs **/

/** Testing API **/
/** STARTs **/
app.get('/api', function (req, res) {
    res.status(200).send('API works.');
});
/** ENDs **/

/** Routing Controllers **/
/** STARTs **/

// Users signup and sigin Endpoint controller
var AuthController = require(__root + 'Routes/auth/AuthController');
app.use('/api/auth', AuthController);

// Users Endpoint controller
var UserController = require(__root + 'Routes/user/UserController');
app.use('/api/users', UserController);

// UserProfile Upload Endpoint controller
var UserProfileController = require(__root + './Routes/UserProfile/UserProfileController');
app.use('/api/profile', UserProfileController);

// Media Upload Endpoint controller
var MediaController = require(__root + './Routes/media/mediaController');
app.use('/api/media', MediaController);
/**
// for Employee Role
router.route('/employee_role').get((req, res) => {
    EmployeeRole.find((err, technologies) => {
        if (err)
            console.log(err);
        else
            res.json(technologies);
        // console.log(res, technologies, '---isssues');
    });
});

// for Technologies
router.route('/technologies').get((req, res) => {
    console.log('---check');

    Technology.find((err, technologies) => {
        console.log(err, technologies, '---isssues');
        if (err)
            console.log(err);
        else
            res.json(technologies);
        console.log(res, technologies, '---isssues');
    });
});

// Single Get API
router.route('/technologies/:id').get((req, res) => {
    console.log(req.params);
    Technology.findById(req.params.id, (err, technology) => {
        console.log(err, technology);
        if (err)
            console.log('err');
        else
            res.json(technology);
    });
});
// Add API
// for Employee Role
router.route('/employee_role').post((req, res) => {
    let empRole = new EmployeeRole(req.body);
    empRole.save()
        .then(empRole => {
            res.status(200).json({
                'EmployeeRole': 'Employee Role added successfully'
            });
        })
        .catch(err => {
            res.status(400).send('Failed to create new record');
        });
});

// for Technologies
router.route('/technologies/add').post((req, res) => {
    let tech = new Technology(req.body);
    tech.save()
        .then(tech => {
            res.status(200).json({
                'technology': 'Technology added successfully'
            });
        })
        .catch(err => {
            res.status(400).send('Failed to create new record');
        });
});
// Update API
router.route('/technologies/update/:id').post((req, res) => {
    Technology.findById(req.params.id, (err, technology) => {
        if (!technology)
            return next(new Error('Could not load document'));
        else {
            technology.name = req.body.name;
            technology.auther = req.body.auther;
            technology.description = req.body.description;
            technology.established = req.body.established;
            technology.latestVersion = req.body.latestVersion;
            technology.docURL = req.body.docURL;

            technology.save().then(technology => {
                res.json('Update done');
            }).catch(err => {
                res.status(400).send('Update failed');
            });
        }
    });
});
//Delete API
router.route('/technologies/delete/:id').delete((req, res) => {
    Technology.findByIdAndRemove({
        _id: req.params.id
    }, (err, technology) => {
        if (err)
            res.json(err);
        else
            res.json('Remove successfully');
    })
});
*/
app.use('/api', router);

/** ENDs **/
/** Creating Server **/

/** STARTs **/
var port = process.env.PORT || 5000;
app.listen(port, () => console.log('Express server running on port ' + port));
/** ENDs **/

// const fs = require('fs');
// const https = require('https');
// const WebSocket = require('ws');
// var express = require('express');
// var path = require('path');
// var app = express();
// // var server = require('http').createServer();

// const server = new https.createServer();
// // var wss = new WebSocket({
// //     server: server.address()
// // });
// // const WebSocket = require('ws');

// const wss = new WebSocket.Server({
//     port: 9090
// });

// wss.on('connection', function (ws) {
//     var id = setInterval(function () {
//         ws.send(JSON.stringify(process.memoryUsage()), function () {
//             /* ignore errors */
//         });
//     }, 100);
//     console.log('started client interval');
//     ws.on('close', function () {
//         console.log('stopping client interval');
//         clearInterval(id);
//     });
// });

// server.listen(8080, function () {
//     console.log('Listening on http://localhost:9090');
// });