/*jshint esversion: 6 */
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import multer from 'multer';
import GridFsStorage from 'multer-gridfs-storage';
import Grid from 'gridfs-stream';

/** Connecting DataBase **/
/** STARTs **/
// Mongo URI
const mongoURI = 'mongodb://localhost:27017/hubstaff';

mongoose.connect(mongoURI, {
    useNewUrlParser: true
});
const connection = mongoose.connection;

// Init gfs
// let gfs;

// connection.once('open', () => {
//     console.log('MongoDB database connection established successfully!');
//     // Init stream
//     // gfs = Grid(connection.db, mongoose.mongo);
//     // gfs.collection('uploads');
// });



module.exports.connection = connection;