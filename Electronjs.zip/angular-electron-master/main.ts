import { app, BrowserWindow, dialog, screen, Tray } from 'electron';
import * as path from 'path';
import * as url from 'url';
const { remote } = require('electron');
const desktopIdle = require('desktop-idle');
/*** Node Notifier - Starts***/
const notifier = require('node-notifier');
const NotificationCenter = require('node-notifier/notifiers/notificationcenter');
const notifierOptions = {
  title: 'My awesome title',
  message: 'Hello from Auxo Idle Tracker, Mr.MuniyappanK',
  icon: path.join(__dirname, 'Timer.png'), // Absolute path (doesn't work on balloons)
  sound: true, // Only Notification Center or Windows Toasters
  wait: true // Wait with callback, until user action is taken against notification
};
// function(err, response) {
//   // Response is response from notification
// }

function focuseCurrentWindow() {
  this.window.show();
    this.window.restore();
  const currentWindow = remote.getCurrentWindow();
  console.log(currentWindow, '--->currentWindow');

  currentWindow.setAlwaysOnTop(true);
  currentWindow.focus();
  currentWindow.setAlwaysOnTop(false);
 	console.log('Focus');
}

notifier.on('click', function(notifierObject, options1) {
  // Triggers if `wait: true` and user clicks notification
  console.log(notifierObject, options1, '===>user clicks notification');
  // focuseCurrentWindow();

});

notifier.on('timeout', function(notifierObject, options1) {
  // Triggers if `wait: true` and notification closes
  console.log(notifierObject, options1, '===>notification closes');
});

// new NotificationCenter(notifierOptions).notify();

const NotifySend = require('node-notifier/notifiers/notifysend');
// new NotifySend(options).notify();

const WindowsToaster = require('node-notifier/notifiers/toaster');
// new WindowsToaster(options).notify();

const Growl = require('node-notifier/notifiers/growl');
// new Growl(options).notify();

const WindowsBalloon = require('node-notifier/notifiers/balloon');
// new WindowsBalloon(options).notify();

/** Ends **/

const options = {
  type: 'info',
  buttons: ['&Yes', '&Cancel'],
  defaultId: 1,
  title: 'Question',
  message: 'Hey! You are Idle.',
  detail: 'You are IDLE more than an 10 minutes',
  // checkboxLabel: 'Remember my answer',
  // checkboxChecked: true,
  normalizeAccessKeys: true
};

// const response = dialog.showMessageBox(null);
// console.log(response);

// app
// import { AppConfig } from './src/environments/environment';
let win, serve, trayIcon;

// electron
const electron = require('electron');
const Menu: any = electron.Menu;
const shell: any = electron.shell;
let mainWindow: any = null;
let template: any = null;
let menu: any;

const args = process.argv.slice(1);
serve = args.some(val => val === '--serve');

const getWindowPosition = () => {
  const windowBounds = mainWindow.getBounds();
  const trayBounds = trayIcon.getBounds();

  // Center window horizontally below the tray icon
  const x = Math.round(trayBounds.x + (trayBounds.width / 2) - (windowBounds.width / 2));

  // Position window 4 pixels vertically below the tray icon
  const y = Math.round(trayBounds.y + trayBounds.height + 4);

  return {x: x, y: y};
};

const showWindow = () => {
  mainWindow.show();
  mainWindow.focus();
};

const toggleWindow = () => {
  if (mainWindow.isVisible()) {
    mainWindow.hide();
  } else {
    showWindow();
  }
};
const createTray = () => {
  // Tray Menu codes
const trayMenuTemplate = [{
  label: 'Auxo Employee tTracker',
  click: function () {
      // console.log("Clicked on About CryptoCurrencyClient")
  }
}, {
  label: 'Settings',
  submenu: [{
          label: 'Set ScreenCapture Time',
          submenu: [{
                  label: '5 mins',
                  type: 'radio',
                  checked: true,
                  click: () => {
                      console.log('Clicked on 5 Minutes');
                      mainWindow.webContents.send('option1', 1);
                  }
              },
              {
                  label: '10 mins',
                  type: 'radio',
                  click: () => {
                      console.log('Clicked on 10 Minutes');
                      mainWindow.webContents.send('option2', 2);
                  }
              },
              {
                label: '15 mins',
                type: 'radio',
                click: () => {
                     console.log('Clicked on 15 Minutes');
                    mainWindow.webContents.send('option3', 2);
                }
            }, {
              label: 'Default(1 min)',
              type: 'radio',
              click: () => {
                  // console.log("Clicked on default(1 Minute)");
                  mainWindow.webContents.send('optionDefault', 2);
              }
          }
            ]
            }]
          },
          {
            label: 'exit',
            accelerator: 'CmdOrCtrl+Esc',
            click: function (item, focusedWindow) {
              console.log(item, focusedWindow, '--->focusedWindow');

                // if (focusedWindow) {
                    app.quit();
                // }
            }
        }];

  trayIcon = new Tray(path.join(__dirname, 'Timer.png'));
  const trayMenu = Menu.buildFromTemplate(trayMenuTemplate);
  trayIcon.setContextMenu(trayMenu);
  trayIcon.setToolTip('Angular7 with Electron');
  // trayIcon.on('right-click', toggleWindow);
  trayIcon.on('double-click', toggleWindow);
  trayIcon.on('click', function (event) {
    // toggleWindow();
    // Show devtools when command clicked
    if (mainWindow.isVisible() && process.defaultApp && event.metaKey) {
      mainWindow.openDevTools({mode: 'detach'});
    }
  });
};


// You would need a valid `submitURL` to use
// crashReporter.start({
//   productName: 'AngularSeedAdvanced',
//   companyName: 'NathanWalker',
//   submitURL: 'https://github.com/NathanWalker/angular-seed-advanced',
//   autoSubmit: true
// });
function GET_SUPPORTED_LANGUAGES() {
  return [
    { code: 'en', title: 'English' },
    { code: 'es', title: 'Spanish' },
    { code: 'fr', title: 'French' },
    { code: 'ru', title: 'Russian' },
    { code: 'bg', title: 'Bulgarian' }
  ];
}
function createWindow() {

  const electronScreen = screen;
  const size = electronScreen.getPrimaryDisplay().workAreaSize;

  // Create the browser window.
  mainWindow = new BrowserWindow({
    x: 0,
    y: 0,
    width: size.width,
    height: size.height,
    webPreferences: {
      nodeIntegration: true,
    },
  });

  createTray();
  if (serve) {
    require('electron-reload')(__dirname, {
      electron: require(`${__dirname}/node_modules/electron`),
    });
    mainWindow.loadURL('http://localhost:4200');
  } else {
    mainWindow.loadURL(url.format({
      pathname: path.join(__dirname, 'dist/index.html'),
      protocol: 'file:',
      slashes: true
    }));
  }

  if (serve) {
    mainWindow.webContents.openDevTools();
  }

    mainWindow.webContents.on('did-navigate-in-page', (e: any, url: string) => {
      // console.log(`${AppConfig.environment}---> Page navigated: ${url}`);
    });

    const appTitle = `Angular Seed Advanced`;

    const langMenu: any = {
      label: 'Language',
      submenu: []
    };
    for (const lang of GET_SUPPORTED_LANGUAGES()) {
      const code = lang.code;
      const langOption = {
        label: lang.title,
        click: () => {
          console.log(`Change lang: ${code}`);
          mainWindow.webContents.executeJavaScript(`window.dispatchEvent(new CustomEvent('changeLang', {detail: { value: '${code}'} }));`);
        }
      };
      langMenu.submenu.push(langOption);
    }

    const helpMenu: any = {
      label: 'Help',
      submenu: [{
        label: 'Learn More',
        click: () => {
          shell.openExternal('https://github.com/NathanWalker/angular-seed-advanced');
        }
      }, {
          label: 'Issues',
          click: () => {
            shell.openExternal('https://github.com/NathanWalker/angular-seed-advanced/issues');
          }
        }, {
          label: `My Amazing Parent: Minko Gechev's Angular Seed`,
          click: () => {
            shell.openExternal('https://github.com/mgechev/angular-seed');
          }
        }, {
          label: 'Angular 2',
          click: () => {
            shell.openExternal('https://angular.io/');
          }
        }, {
          label: 'Electron',
          click: () => {
            shell.openExternal('http://electron.atom.io/');
          }
        }, {
          label: 'Electron Docs',
          click: () => {
            shell.openExternal('https://github.com/atom/electron/tree/master/docs');
          }
        }, {
          label: 'Codeology Visualization',
          click: () => {
            shell.openExternal('http://codeology.braintreepayments.com/nathanwalker/angular-seed-advanced');
          }
        }]
    };

    if (process.platform === 'darwin') {
      template = [{
        label: appTitle,
        submenu: [{
          label: `About ${appTitle}`,
          selector: 'orderFrontStandardAboutPanel:'
        }, {
            type: 'separator'
          }, {
            label: 'Services',
            submenu: []
          }, {
            type: 'separator'
          }, {
            label: 'Hide Angular Seed Advanced',
            accelerator: 'Command+H',
            selector: 'hide:'
          }, {
            label: 'Hide Others',
            accelerator: 'Command+Shift+H',
            selector: 'hideOtherApplications:'
          }, {
            label: 'Show All',
            selector: 'unhideAllApplications:'
          }, {
            type: 'separator'
          }, {
            label: 'Quit',
            accelerator: 'Command+Q',
            click: () => {
              app.quit();
            }
          }]
      }, {
          label: 'Edit',
          submenu: [{
            label: 'Undo',
            accelerator: 'Command+Z',
            selector: 'undo:'
          }, {
              label: 'Redo',
              accelerator: 'Shift+Command+Z',
              selector: 'redo:'
            }, {
              type: 'separator'
            }, {
              label: 'Cut',
              accelerator: 'Command+X',
              selector: 'cut:'
            }, {
              label: 'Copy',
              accelerator: 'Command+C',
              selector: 'copy:'
            }, {
              label: 'Paste',
              accelerator: 'Command+V',
              selector: 'paste:'
            }, {
              label: 'Select All',
              accelerator: 'Command+A',
              selector: 'selectAll:'
            }]
        }, {
          label: 'View',
          submenu: [{
            label: 'Reload',
            accelerator: 'Command+R',
            click: () => {
              mainWindow.reload();
            }
          }, {
              label: 'Toggle Full Screen',
              accelerator: 'Ctrl+Command+F',
              click: () => {
                mainWindow.setFullScreen(!mainWindow.isFullScreen());
              }
            }, {
              label: 'Toggle Developer Tools',
              accelerator: 'Alt+Command+I',
              click: () => {
                mainWindow.toggleDevTools();
              }
            }]
        }, {
          label: 'Window',
          submenu: [{
            label: 'Minimize',
            accelerator: 'Command+M',
            selector: 'performMiniaturize:'
          }, {
              label: 'Close',
              accelerator: 'Command+W',
              selector: 'performClose:'
            }, {
              type: 'separator'
            }, {
              label: 'Bring All to Front',
              selector: 'arrangeInFront:'
            }]
        },
        langMenu,
        helpMenu];

      menu = Menu.buildFromTemplate(template);
      Menu.setApplicationMenu(menu);
    } else {
      template = [{
        label: '&File',
        submenu: [{
          label: '&Open',
          accelerator: 'Ctrl+O'
        }, {
            label: '&Close',
            accelerator: 'Ctrl+W',
            click: () => {
              mainWindow.close();
            }
          }]
      }, {
          label: '&View',
          submenu: [{
            label: '&Reload',
            accelerator: 'Ctrl+R',
            click: () => {
              mainWindow.reload();
            }
          }, {
              label: 'Toggle &Full Screen',
              accelerator: 'F11',
              click: () => {
                mainWindow.setFullScreen(!mainWindow.isFullScreen());
              }
            }, {
              label: 'Toggle Developer Tools',
              accelerator: 'Ctrl+Shift+I',
              click: function (item, focusedWindow) {
                  if (focusedWindow) {
                      focusedWindow.toggleDevTools();
                  }
              }
          }]
          //  : [{
          //     label: 'Toggle &Full Screen',
          //     accelerator: 'F11',
          //     click: () => {
          //       mainWindow.setFullScreen(!mainWindow.isFullScreen());
          //     }
          //   }]
        },
        langMenu,
        helpMenu];
      menu = Menu.buildFromTemplate(template);
      mainWindow.setMenu(menu);
    }
  }

try {

  // This method will be called when Electron has finished
  // initialization and is ready to create browser windows.
  // Some APIs can only be used after this event occurs.
  app.on('ready', () => {

    createWindow();

    /** To check the system is idl or not on every seconds**/
    setInterval(function() {
      console.log(desktopIdle.getIdleTime());
      if (desktopIdle.getIdleTime() % 10 === 0 && desktopIdle.getIdleTime() !== 0) {
        dialog.showMessageBox(mainWindow, options, (response, checkboxChecked) => {
          console.log(response);
          console.log(checkboxChecked);
        });

        notifier.notify(notifierOptions,
          function(err, response) {
            showWindow();
            // Response is response from notification
            console.log(err, response, '===>>>');
          });

      }
  }, 1000);


  });


  // Emitted when the window is closed.
  mainWindow.on('closed', () => {
    // Dereference the window object, usually you would store window
    // in an array if your app supports multi windows, this is the time
    // when you should delete the corresponding element.
    mainWindow = null;
  });


  // Quit when all windows are closed.
  app.on('window-all-closed', () => {
    // On OS X it is common for applications and their menu bar
    // to stay active until the user quits explicitly with Cmd + Q
    if (process.platform !== 'darwin') {
      app.quit();
    }
  });

  app.on('activate', () => {
    // On OS X it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (mainWindow === null) {
      createWindow();
    }
  });

} catch (e) {
  // Catch Error
  // throw e;
}

