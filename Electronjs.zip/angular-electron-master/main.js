"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var electron_1 = require("electron");
var path = require("path");
var url = require("url");
var remote = require('electron').remote;
var desktopIdle = require('desktop-idle');
/*** Node Notifier - Starts***/
var notifier = require('node-notifier');
var NotificationCenter = require('node-notifier/notifiers/notificationcenter');
var notifierOptions = {
    title: 'My awesome title',
    message: 'Hello from Auxo Idle Tracker, Mr.MuniyappanK',
    icon: path.join(__dirname, 'Timer.png'),
    sound: true,
    wait: true // Wait with callback, until user action is taken against notification
};
// function(err, response) {
//   // Response is response from notification
// }
function focuseCurrentWindow() {
    this.window.show();
    this.window.restore();
    var currentWindow = remote.getCurrentWindow();
    console.log(currentWindow, '--->currentWindow');
    currentWindow.setAlwaysOnTop(true);
    currentWindow.focus();
    currentWindow.setAlwaysOnTop(false);
    console.log('Focus');
}
notifier.on('click', function (notifierObject, options1) {
    // Triggers if `wait: true` and user clicks notification
    console.log(notifierObject, options1, '===>user clicks notification');
    // focuseCurrentWindow();
});
notifier.on('timeout', function (notifierObject, options1) {
    // Triggers if `wait: true` and notification closes
    console.log(notifierObject, options1, '===>notification closes');
});
// new NotificationCenter(notifierOptions).notify();
var NotifySend = require('node-notifier/notifiers/notifysend');
// new NotifySend(options).notify();
var WindowsToaster = require('node-notifier/notifiers/toaster');
// new WindowsToaster(options).notify();
var Growl = require('node-notifier/notifiers/growl');
// new Growl(options).notify();
var WindowsBalloon = require('node-notifier/notifiers/balloon');
// new WindowsBalloon(options).notify();
/** Ends **/
var options = {
    type: 'info',
    buttons: ['&Yes', '&Cancel'],
    defaultId: 1,
    title: 'Question',
    message: 'Hey! You are Idle.',
    detail: 'You are IDLE more than an 10 minutes',
    // checkboxLabel: 'Remember my answer',
    // checkboxChecked: true,
    normalizeAccessKeys: true
};
// const response = dialog.showMessageBox(null);
// console.log(response);
// app
// import { AppConfig } from './src/environments/environment';
var win, serve, trayIcon;
// electron
var electron = require('electron');
var Menu = electron.Menu;
var shell = electron.shell;
var mainWindow = null;
var template = null;
var menu;
var args = process.argv.slice(1);
serve = args.some(function (val) { return val === '--serve'; });
var getWindowPosition = function () {
    var windowBounds = mainWindow.getBounds();
    var trayBounds = trayIcon.getBounds();
    // Center window horizontally below the tray icon
    var x = Math.round(trayBounds.x + (trayBounds.width / 2) - (windowBounds.width / 2));
    // Position window 4 pixels vertically below the tray icon
    var y = Math.round(trayBounds.y + trayBounds.height + 4);
    return { x: x, y: y };
};
var showWindow = function () {
    mainWindow.show();
    mainWindow.focus();
};
var toggleWindow = function () {
    if (mainWindow.isVisible()) {
        mainWindow.hide();
    }
    else {
        showWindow();
    }
};
var createTray = function () {
    // Tray Menu codes
    var trayMenuTemplate = [{
            label: 'Auxo Employee tTracker',
            click: function () {
                // console.log("Clicked on About CryptoCurrencyClient")
            }
        }, {
            label: 'Settings',
            submenu: [{
                    label: 'Set ScreenCapture Time',
                    submenu: [{
                            label: '5 mins',
                            type: 'radio',
                            checked: true,
                            click: function () {
                                console.log('Clicked on 5 Minutes');
                                mainWindow.webContents.send('option1', 1);
                            }
                        },
                        {
                            label: '10 mins',
                            type: 'radio',
                            click: function () {
                                console.log('Clicked on 10 Minutes');
                                mainWindow.webContents.send('option2', 2);
                            }
                        },
                        {
                            label: '15 mins',
                            type: 'radio',
                            click: function () {
                                console.log('Clicked on 15 Minutes');
                                mainWindow.webContents.send('option3', 2);
                            }
                        }, {
                            label: 'Default(1 min)',
                            type: 'radio',
                            click: function () {
                                // console.log("Clicked on default(1 Minute)");
                                mainWindow.webContents.send('optionDefault', 2);
                            }
                        }
                    ]
                }]
        },
        {
            label: 'exit',
            accelerator: 'CmdOrCtrl+Esc',
            click: function (item, focusedWindow) {
                console.log(item, focusedWindow, '--->focusedWindow');
                // if (focusedWindow) {
                electron_1.app.quit();
                // }
            }
        }];
    trayIcon = new electron_1.Tray(path.join(__dirname, 'Timer.png'));
    var trayMenu = Menu.buildFromTemplate(trayMenuTemplate);
    trayIcon.setContextMenu(trayMenu);
    trayIcon.setToolTip('Angular7 with Electron');
    // trayIcon.on('right-click', toggleWindow);
    trayIcon.on('double-click', toggleWindow);
    trayIcon.on('click', function (event) {
        // toggleWindow();
        // Show devtools when command clicked
        if (mainWindow.isVisible() && process.defaultApp && event.metaKey) {
            mainWindow.openDevTools({ mode: 'detach' });
        }
    });
};
// You would need a valid `submitURL` to use
// crashReporter.start({
//   productName: 'AngularSeedAdvanced',
//   companyName: 'NathanWalker',
//   submitURL: 'https://github.com/NathanWalker/angular-seed-advanced',
//   autoSubmit: true
// });
function GET_SUPPORTED_LANGUAGES() {
    return [
        { code: 'en', title: 'English' },
        { code: 'es', title: 'Spanish' },
        { code: 'fr', title: 'French' },
        { code: 'ru', title: 'Russian' },
        { code: 'bg', title: 'Bulgarian' }
    ];
}
function createWindow() {
    var electronScreen = electron_1.screen;
    var size = electronScreen.getPrimaryDisplay().workAreaSize;
    // Create the browser window.
    mainWindow = new electron_1.BrowserWindow({
        x: 0,
        y: 0,
        width: size.width,
        height: size.height,
        webPreferences: {
            nodeIntegration: true,
        },
    });
    createTray();
    if (serve) {
        require('electron-reload')(__dirname, {
            electron: require(__dirname + "/node_modules/electron"),
        });
        mainWindow.loadURL('http://localhost:4200');
    }
    else {
        mainWindow.loadURL(url.format({
            pathname: path.join(__dirname, 'dist/index.html'),
            protocol: 'file:',
            slashes: true
        }));
    }
    if (serve) {
        mainWindow.webContents.openDevTools();
    }
    mainWindow.webContents.on('did-navigate-in-page', function (e, url) {
        // console.log(`${AppConfig.environment}---> Page navigated: ${url}`);
    });
    var appTitle = "Angular Seed Advanced";
    var langMenu = {
        label: 'Language',
        submenu: []
    };
    var _loop_1 = function (lang) {
        var code = lang.code;
        var langOption = {
            label: lang.title,
            click: function () {
                console.log("Change lang: " + code);
                mainWindow.webContents.executeJavaScript("window.dispatchEvent(new CustomEvent('changeLang', {detail: { value: '" + code + "'} }));");
            }
        };
        langMenu.submenu.push(langOption);
    };
    for (var _i = 0, _a = GET_SUPPORTED_LANGUAGES(); _i < _a.length; _i++) {
        var lang = _a[_i];
        _loop_1(lang);
    }
    var helpMenu = {
        label: 'Help',
        submenu: [{
                label: 'Learn More',
                click: function () {
                    shell.openExternal('https://github.com/NathanWalker/angular-seed-advanced');
                }
            }, {
                label: 'Issues',
                click: function () {
                    shell.openExternal('https://github.com/NathanWalker/angular-seed-advanced/issues');
                }
            }, {
                label: "My Amazing Parent: Minko Gechev's Angular Seed",
                click: function () {
                    shell.openExternal('https://github.com/mgechev/angular-seed');
                }
            }, {
                label: 'Angular 2',
                click: function () {
                    shell.openExternal('https://angular.io/');
                }
            }, {
                label: 'Electron',
                click: function () {
                    shell.openExternal('http://electron.atom.io/');
                }
            }, {
                label: 'Electron Docs',
                click: function () {
                    shell.openExternal('https://github.com/atom/electron/tree/master/docs');
                }
            }, {
                label: 'Codeology Visualization',
                click: function () {
                    shell.openExternal('http://codeology.braintreepayments.com/nathanwalker/angular-seed-advanced');
                }
            }]
    };
    if (process.platform === 'darwin') {
        template = [{
                label: appTitle,
                submenu: [{
                        label: "About " + appTitle,
                        selector: 'orderFrontStandardAboutPanel:'
                    }, {
                        type: 'separator'
                    }, {
                        label: 'Services',
                        submenu: []
                    }, {
                        type: 'separator'
                    }, {
                        label: 'Hide Angular Seed Advanced',
                        accelerator: 'Command+H',
                        selector: 'hide:'
                    }, {
                        label: 'Hide Others',
                        accelerator: 'Command+Shift+H',
                        selector: 'hideOtherApplications:'
                    }, {
                        label: 'Show All',
                        selector: 'unhideAllApplications:'
                    }, {
                        type: 'separator'
                    }, {
                        label: 'Quit',
                        accelerator: 'Command+Q',
                        click: function () {
                            electron_1.app.quit();
                        }
                    }]
            }, {
                label: 'Edit',
                submenu: [{
                        label: 'Undo',
                        accelerator: 'Command+Z',
                        selector: 'undo:'
                    }, {
                        label: 'Redo',
                        accelerator: 'Shift+Command+Z',
                        selector: 'redo:'
                    }, {
                        type: 'separator'
                    }, {
                        label: 'Cut',
                        accelerator: 'Command+X',
                        selector: 'cut:'
                    }, {
                        label: 'Copy',
                        accelerator: 'Command+C',
                        selector: 'copy:'
                    }, {
                        label: 'Paste',
                        accelerator: 'Command+V',
                        selector: 'paste:'
                    }, {
                        label: 'Select All',
                        accelerator: 'Command+A',
                        selector: 'selectAll:'
                    }]
            }, {
                label: 'View',
                submenu: [{
                        label: 'Reload',
                        accelerator: 'Command+R',
                        click: function () {
                            mainWindow.reload();
                        }
                    }, {
                        label: 'Toggle Full Screen',
                        accelerator: 'Ctrl+Command+F',
                        click: function () {
                            mainWindow.setFullScreen(!mainWindow.isFullScreen());
                        }
                    }, {
                        label: 'Toggle Developer Tools',
                        accelerator: 'Alt+Command+I',
                        click: function () {
                            mainWindow.toggleDevTools();
                        }
                    }]
            }, {
                label: 'Window',
                submenu: [{
                        label: 'Minimize',
                        accelerator: 'Command+M',
                        selector: 'performMiniaturize:'
                    }, {
                        label: 'Close',
                        accelerator: 'Command+W',
                        selector: 'performClose:'
                    }, {
                        type: 'separator'
                    }, {
                        label: 'Bring All to Front',
                        selector: 'arrangeInFront:'
                    }]
            },
            langMenu,
            helpMenu];
        menu = Menu.buildFromTemplate(template);
        Menu.setApplicationMenu(menu);
    }
    else {
        template = [{
                label: '&File',
                submenu: [{
                        label: '&Open',
                        accelerator: 'Ctrl+O'
                    }, {
                        label: '&Close',
                        accelerator: 'Ctrl+W',
                        click: function () {
                            mainWindow.close();
                        }
                    }]
            }, {
                label: '&View',
                submenu: [{
                        label: '&Reload',
                        accelerator: 'Ctrl+R',
                        click: function () {
                            mainWindow.reload();
                        }
                    }, {
                        label: 'Toggle &Full Screen',
                        accelerator: 'F11',
                        click: function () {
                            mainWindow.setFullScreen(!mainWindow.isFullScreen());
                        }
                    }, {
                        label: 'Toggle Developer Tools',
                        accelerator: 'Ctrl+Shift+I',
                        click: function (item, focusedWindow) {
                            if (focusedWindow) {
                                focusedWindow.toggleDevTools();
                            }
                        }
                    }]
                //  : [{
                //     label: 'Toggle &Full Screen',
                //     accelerator: 'F11',
                //     click: () => {
                //       mainWindow.setFullScreen(!mainWindow.isFullScreen());
                //     }
                //   }]
            },
            langMenu,
            helpMenu];
        menu = Menu.buildFromTemplate(template);
        mainWindow.setMenu(menu);
    }
}
try {
    // This method will be called when Electron has finished
    // initialization and is ready to create browser windows.
    // Some APIs can only be used after this event occurs.
    electron_1.app.on('ready', function () {
        createWindow();
        /** To check the system is idl or not on every seconds**/
        setInterval(function () {
            console.log(desktopIdle.getIdleTime());
            if (desktopIdle.getIdleTime() % 10 === 0 && desktopIdle.getIdleTime() !== 0) {
                electron_1.dialog.showMessageBox(mainWindow, options, function (response, checkboxChecked) {
                    console.log(response);
                    console.log(checkboxChecked);
                });
                notifier.notify(notifierOptions, function (err, response) {
                    showWindow();
                    // Response is response from notification
                    console.log(err, response, '===>>>');
                });
            }
        }, 1000);
    });
    // Emitted when the window is closed.
    mainWindow.on('closed', function () {
        // Dereference the window object, usually you would store window
        // in an array if your app supports multi windows, this is the time
        // when you should delete the corresponding element.
        mainWindow = null;
    });
    // Quit when all windows are closed.
    electron_1.app.on('window-all-closed', function () {
        // On OS X it is common for applications and their menu bar
        // to stay active until the user quits explicitly with Cmd + Q
        if (process.platform !== 'darwin') {
            electron_1.app.quit();
        }
    });
    electron_1.app.on('activate', function () {
        // On OS X it's common to re-create a window in the app when the
        // dock icon is clicked and there are no other windows open.
        if (mainWindow === null) {
            createWindow();
        }
    });
}
catch (e) {
    // Catch Error
    // throw e;
}
//# sourceMappingURL=main.js.map