"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppConfig = {
    production: false,
    environment: 'LOCAL'
};
//# sourceMappingURL=environment.js.map