import { Injectable } from '@angular/core';
import * as childProcess from 'child_process';
// If you import a module but never use any of the imported values other than as TypeScript types,
// the resulting javascript file will look as if you never imported the module at all.
import { desktopCapturer, ipcRenderer, Menu, remote, Tray, webFrame } from 'electron';
import * as fs from 'fs';
import * as path from 'path';


@Injectable()
export class ElectronService {

  desktopCapturer: typeof desktopCapturer;
  ipcRenderer: typeof ipcRenderer;
  webFrame: typeof webFrame;
  remote: typeof remote;
  childProcess: typeof childProcess;
  fs: typeof fs;
  Tray: typeof Tray;
  path: typeof path;
  Menu: typeof Menu;
  domify: any;
  constructor() {
    // Conditional imports
    if (this.isElectron()) {
      this.desktopCapturer = window.require('electron').desktopCapturer;
      this.ipcRenderer = window.require('electron').ipcRenderer;
      this.webFrame = window.require('electron').webFrame;
      this.remote = window.require('electron').remote;
      this.childProcess = window.require('child_process');
      this.fs = window.require('fs');

      this.Tray = window.require('electron').Tray;
      this.path = path;
      this.Menu = window.require('electron').Menu;
      this.domify = window.require('domify');
    }
  }

  isElectron = () => {
    return window && window.process && window.process.type;
  }

}


