import { Injectable } from '@angular/core';
import { BehaviorSubject, interval, Observable } from 'rxjs';
import { map, takeWhile } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CounterService {
  private time = new BehaviorSubject<any>(null);
  timerValue = this.time.asObservable();
  countDown;
  isTimerAlive = true;
  isScreenCaptureAlive = false;
  counter = 10;
  tick = 1000;
  constructor() { }

  getCounter(): Observable<any> {
    return interval(1000)
    .pipe(takeWhile(() => this.isTimerAlive ), map(() => ++this.counter));
  }

  updateTimerData(timerVal) {
    this.time.next(timerVal);
  }

  readTimerData(): Observable<any> {
    return this.timerValue;
  }
}
