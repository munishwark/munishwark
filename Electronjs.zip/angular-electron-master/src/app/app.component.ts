import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { AppConfig } from '../environments/environment';
import { ElectronService } from './providers/electron.service';
import { SideNaveService } from './services/side-nave.service';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  @ViewChild('drawer') public sideNave: MatSidenav;

  // sideNave: MatSidenav;
  public isHide = true;
  public linksAfterLogIn = [];
  public linksBeforeLogIn = [];
  public sideNavLinks = [];
  public isLoggedIn: Subscription;
  isHandset$: Observable<boolean> = this.breakpointObserver
    .observe(Breakpoints.Handset)
    .pipe(map(result => result.matches));
  constructor(public electronService: ElectronService,
    private translate: TranslateService,    private breakpointObserver: BreakpointObserver, private _sideNavService: SideNaveService
    ) {

    translate.setDefaultLang('en');
    console.log('AppConfig', AppConfig);

    if (electronService.isElectron()) {
      console.log('Mode electron');
      console.log('Electron ipcRenderer', electronService.ipcRenderer);
      console.log('NodeJS childProcess', electronService.childProcess);
    } else {
      console.log('Mode web');
    }
  }

    ngOnInit() {
      // this._sideNavService.setSidenav(this.sideNave);
    }
    ngAfterViewInit() {
      this._sideNavService.setSidenav(this.sideNave);
    }
    togleMenu() {
      this.isHide = !this.isHide;
    }

    openSideNave() {
      this._sideNavService.sideNaveOpen();
    }

    closeSideNave() {
      this._sideNavService.sideNaveClose();
    }

    toggleSideNave() {
        console.log(this.sideNave.opened, '--->');
      this._sideNavService.sideNaveToggle();
    }
}
