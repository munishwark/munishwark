import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import * as fs from 'fs';
import { interval, Subscription } from 'rxjs';
import { takeWhile } from 'rxjs/operators';
import { CounterService } from '../../modules/shared/components/navbar/counter.service';
import { ElectronService } from '../../providers/electron.service';
import { ScreenshotTrackerService } from '../../services/screenshot-tracker.service';

const uuidv4 = require('uuid/v4');
const os = require('os');
const mkdirp = require('mkdirp');
const getDirName = require('path').dirname;
const n = <any>navigator;
let basePath = null;
const screenShotPath = '';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  isAliveScreenCapture = false;
  intervalSubscription: Subscription = new Subscription();
  constructor(public electronService: ElectronService,
    private translate: TranslateService, private ScreenCaptureTracker: ScreenshotTrackerService, private _CounterService: CounterService) {
    translate.setDefaultLang('en');
    if (electronService.isElectron()) {
      const app = electronService.remote.app;
      basePath = app.getAppPath();
    } else {
      console.log('Mode web');
    }
  }

  ngOnInit() {
    this.electronService.ipcRenderer.on('Radio Option1', (event, val) => {
      console.log(event, val, '--->');
    });
  }
  function() {
    throw new Error('Method not implemented.');
  }
  startCapturingScreenShot() {
if (!this.ScreenCaptureTracker.isScreenCaptureAlive) {
  this.ScreenCaptureTracker.updateScreenCaptureData(true);
}
    this.ScreenCaptureTracker.readScreenCaptureData().subscribe(isScreenCaptureAlive => {
      console.log(isScreenCaptureAlive, '===>isScreenCaptureAlive');
      this.ScreenCaptureTracker.isScreenCaptureAlive = isScreenCaptureAlive;
      this.isAliveScreenCapture = isScreenCaptureAlive;
if (this.ScreenCaptureTracker.isScreenCaptureAlive) {
  this._CounterService.isTimerAlive =  true;
  this._CounterService.getCounter().subscribe(x => {
    this._CounterService.updateTimerData(x);
  });

  this.intervalSubscription = interval(10000).pipe(takeWhile(() => this.ScreenCaptureTracker.isScreenCaptureAlive )).subscribe(x => {
    this.ScreenCaptureTracker.startRecording();
  });
}
    });

  }

  stopCapturingScreenShot() {
    this._CounterService.isTimerAlive = false;
    if (this.ScreenCaptureTracker.isScreenCaptureAlive) {
      this.ScreenCaptureTracker.updateScreenCaptureData(false);
    }
  }


      handleStream (stream) {
        const video = document.querySelector('video');
        video.srcObject = stream;
        this.gotStream(stream);
        video.onloadedmetadata = (e) => video.play();
      }

      gotStream(stream) {
        const randomnumber = Math.floor(Math.random() * 11);
        const video = document.querySelector('video');
        video.addEventListener('loadedmetadata', function () {
            const canvas = document.createElement('canvas');
            canvas.width = this.videoWidth;
            canvas.height = this.videoHeight;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(this, 0, 0);

            const dot = '.';
            const url = canvas.toDataURL('image/jpeg', 1.0);
            const ext = url.split(';')[0].match(/jpeg|png|gif/)[0];
            const data1 = url.replace(/^data:image\/\w+;base64,/, '');

            fs.writeFile('C:/Users/user/Downloads/image' + randomnumber + dot + ext, data1, 'base64', function (err) {
                console.warn('fs');
                if (err) {
                    alert('An error ocurred creating the file ' + err.message);
                }
            });

           }, false);

        video.srcObject = stream;
        // video.play();
  }

  addImage(image) {
    const snap = document.createElement('img');
    snap.src = image.toDataURL();
    document.body.appendChild(snap);
}

handleError(e) {
  console.log('getUserMediaError');
}

}
