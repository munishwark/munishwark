import { Injectable } from '@angular/core';
import { MatSidenav } from '@angular/material';

@Injectable({
  providedIn: 'root'
})

export class SideNaveService {
    private sideNave: MatSidenav;


    public setSidenav(sideNave: MatSidenav) {
      this.sideNave = sideNave;
  }

  public sideNaveOpen() {
      return this.sideNave.open();
  }


  public sideNaveClose() {
      return this.sideNave.close();
  }

  public sideNaveToggle(): void {
  this.sideNave.toggle();
 }
}