import { Injectable } from '@angular/core';
import { desktopCapturer, screen } from 'electron';
import * as fs from 'fs';
import * as path from 'path';
import { BehaviorSubject, Observable } from 'rxjs';
const uuidv4 = require('uuid/v4');
const os = require('os');
const mkdirp = require('mkdirp');
const getDirName = require('path').dirname;
const n = <any>navigator;
const basePath = null;
let screenShotPath = '';
@Injectable({
  providedIn: 'root'
})
export class ScreenshotTrackerService {
  private screenCapture = new BehaviorSubject<any>(null);
  private isStoppedScreenCapture = new BehaviorSubject<any>(false);
  isScreenCaptureAlive = false;
  isScreenCapture = this.isStoppedScreenCapture.asObservable();
  screenCaptureSubscription = this.screenCapture.asObservable();
  constructor() { }
  setScreenCaptureSubscription(isStopped: boolean) {
    this.isStoppedScreenCapture.next(isStopped);
    // this.screenCapture.next(data);
  }

  getScreenCapture() {
    return this.isStoppedScreenCapture.next(this.isStoppedScreenCapture);
  }
  stopScreenCaptureEvent() {
    this.screenCapture.unsubscribe();
  }

  updateScreenCaptureData(isScreenAlive) {
    this.isStoppedScreenCapture.next(isScreenAlive);
  }

  readScreenCaptureData(): Observable<any> {
    return this.isStoppedScreenCapture;
  }

  startRecording() {
    console.log('started Recording');
    const temp = this.determineScreenshot();
    desktopCapturer.getSources({ types: ['window', 'screen'], thumbnailSize: temp }).then(async (sources: any) => {
        console.log(sources);
        const randomnumber = Math.floor(Math.random() * 11);
        sources.forEach(function (source, i) {
           if (source.name === 'Entire screen' || source.name === 'Screen 1' ) {
                    // screenShotPath = path.join(os.tmpdir(), 'screenshot' + randomnumber + '.jpeg');
                    screenShotPath = path.join(os.tmpdir() + '/screenShots/', 'screenshot-' + uuidv4() + '.jpeg');
                    console.log(screenShotPath, '===>screenShotPath');

                    mkdirp(getDirName(screenShotPath), function (err) {
                      if (err) { return console.log(err); }
                      fs.writeFile(screenShotPath, source.thumbnail.toPNG(), function (err) {
                        if (err) { return console.log(err.message); }
                        // shell.openExternal('file://' + screenShotPath);
                        const message = 'Saved SS to ' + screenShotPath;
                    });
                    });
           }
        });
    });
        }

        determineScreenshot() {
          const screensize = screen.getPrimaryDisplay().workAreaSize;
          const maxDimension = Math.max(screensize.width, screensize.height);
          return {
              width: maxDimension * window.devicePixelRatio,
              height: maxDimension * window.devicePixelRatio
          };
        }

}
