# Electron Tray

simple MacOS tray app

## Getting started

- Install [Node LTS](https://nodejs.org)
- Clone this repository
- `cd electron-tray`
- `npm install` to install the application's dependencies
- `npm start` to start the application
