# URL

Simple [Electron](http://electron.atom.io) application that loads a URL
passed on the command line in a window.

## Getting started

- Install [Node LTS](https://nodejs.org)
- Clone this repository
- `cd url`
- `npm install` to install the application's dependencies
- `npm start https://github.com` to start the application and load GitHub
