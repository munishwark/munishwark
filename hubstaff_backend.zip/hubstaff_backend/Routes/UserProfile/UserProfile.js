var mongoose = require('mongoose');
const autoIncrement = require('mongoose-auto-increment');
var timestamps = require('mongoose-timestamp');

var profileSchema = new mongoose.Schema({
    employeeId: mongoose.Schema.Types.ObjectId,
    file_path: {
        type: String,
    },
    caption: {
        type: String,
    },
    employee: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee'
    },
    file_data: {
        type: Object,
    }

});

profileSchema.plugin(timestamps);
mongoose.model('Profile', profileSchema);
module.exports = mongoose.model('Profile');