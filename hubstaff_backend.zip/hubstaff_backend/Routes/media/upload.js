/*jshint esversion: 6 */
var mongoose = require('mongoose');
const autoIncrement = require('mongoose-auto-increment');
var timestamps = require('mongoose-timestamp');

var videoSchema = new mongoose.Schema({
    file_path: {
        type: String,
    },
    caption: {
        type: String,
    },
    file_data: {
        type: Object,
    }

});

videoSchema.plugin(timestamps);
mongoose.model('Video', videoSchema);
module.exports = mongoose.model('Video');